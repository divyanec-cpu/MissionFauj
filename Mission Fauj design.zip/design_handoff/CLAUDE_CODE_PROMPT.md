# Prompt for Claude Code — Build MissionFauj

Copy everything below into Claude Code as your task prompt.

---

Build a mobile-first, responsive web app called **MissionFauj** — an exam-prep and SSB-training app for Indian defence-services aspirants (NDA/NA, CDS, AFCAT, and other officer-entry schemes).

## Reference materials
The `design/` folder in this repo contains six HTML design prototypes — **visual and flow references only, not production code to copy verbatim**. Recreate them pixel-close in your chosen stack (React + Tailwind or CSS Modules recommended), using real components/state instead of the prototypes' inline styles.

Files:
- `Onboarding Eligibility.dc.html` — eligibility briefing → candidate profile form → animated scan → eligibility report (per-scheme eligible/not-eligible cards with reasons)
- `Written Exam Prep.dc.html` — NDA/CDS/AFCAT prep hubs (chapters, progress, mocks, current-affairs digest, quizzes, AI Assist), gated by eligibility, leading to a features overview and a pricing screen with 7-day free trial
- `SSB Training.dc.html` — SSB registration (entry scheme + attempt count) → training-module hub (Psychology, Group Testing, Interview & Self-Assessment) → per-module paywall (skipped if already subscribed) → free bonus modules (English & Confidence, AI Assistant capped at 3 free Q&A in trial, unlimited when paid)
- `Expert Consultation.dc.html` — book 1-on-1 sessions with retired IO/GTO/Psychologist/Board President + a bonus English & Confidence coach category → slot picker → confirmation
- `Help Center.dc.html` — eligibility/qualification reference table, day-by-day SSB process explainer, searchable FAQ
- `Glossary.dc.html` — full-form lookup for every abbreviation used in the app

## Visual direction (must follow exactly)
Disciplined, military-inspired, modern — not costume-y.
- **Palette**: near-black olive ground (`#12130e`), dark olive panels (`#1b1d15` / `#22251a`), hairline olive-grey borders (`#3a3d2e`), khaki text accent (`#c9bd97`), muted warm grey body text (`#9b9a86`), amber/gold primary accent (`#d99a3d`), sage-olive "eligible/success" color (`#7a8b4f`), muted rust "not-eligible/warning" color (`#9c5b3c`), steel-blue-grey secondary (`#5c6670`).
- **Type**: Rajdhani (600/700) for all headings/labels/buttons, uppercase with letterspacing; IBM Plex Sans (400/500/600) for body copy.
- **Geometry**: sharp angular clip-path corners on cards/buttons/badges (small notched corners, not full rectangles) — no rounded corners anywhere. Left-border or top-border accent stripes on cards (3–4px, amber/steel/sage depending on category).
- **Motion**: subtle fade+rise-in on screen/section entry (~10px translateY, 300–500ms ease), animated progress bars, staggered checklist reveal on the eligibility-scan screen.
- Avoid gradients, emoji, rounded pill buttons, drop shadows — the whole system should read flat, disciplined, high-contrast.

## Core flows to implement
1. **Onboarding & eligibility**: capture age (16–45, 0.5-year steps), gender, marital status, education level, 12th stream (conditional), NCC status → evaluate against ~13 entry schemes (NDA Army/Navy/AF, Naval Academy, CDS-IMA/INA/AFA/OTA, AFCAT Flying/Ground, TES, NCC Special Entry, Territorial Army) with real age/education/marital rules → animated scan → eligible/not-eligible report with per-scheme reasons.
2. **Written-exam prep**: only show tabs for exams the user is eligible for; each exam has its own hub layout (NDA = chapter accordion, CDS = track toggle IMA/INA/AFA vs OTA, AFCAT = dual AFCAT/EKT tracks with branch picker); shared: mock-test launcher, current-affairs digest (with AI-assist chat), quizzes, daily streak.
3. **Paywalls**: every premium action (written-exam plans, SSB modules) leads to a plan/pricing screen with a prominent **7-day free trial** CTA — no live payment integration needed, just the UI state. Users already subscribed skip straight past the paywall to an "unlocked" state. Existing app members get an automatic 20% discount on SSB enrollment (show original price struck through).
4. **SSB training**: registration (entry scheme, attempt count) → module hub grouped by Psychology / Group Testing / Interview & Self-Assessment, each ending in **self-review against a rubric — never a numeric AI score**. Two always-free bonus modules regardless of subscription: English & Confidence study material, and an AI Assistant (explains OLQs/structure, never scores answers; 3 free Q&A/trial, unlimited when subscribed).
5. **Expert consultation** (explicitly a v1.1+ stretch beyond MVP, included at product owner's request): book time with retired IO/GTO/Psychologist/Board President plus a bonus English & Confidence coach; category filter → expert card (designation, credentials, bio, price — leave real names/bios as CMS-editable placeholders) → slot picker → confirmation.
6. **Help Center**: searchable FAQ (client-side substring match against Q+A) plus static eligibility table and 5-day SSB process breakdown.
7. **Glossary**: static full-form lookup, grouped by category (Entry Schemes / SSB & Psychology / Written Exam / General).

## Non-negotiable product rules
- Never auto-score SSB psychology or interview content (TAT/WAT/SRT/SD/PIQ/interview) — every such exercise ends in self-review against a rubric, not an AI/algorithmic verdict.
- WAT: 15 seconds per word, no backspace/edit during the timer. TAT: 30s image view + 4 min write. PPDT: 30s picture view. No audio/video recording anywhere in GTO/psych modules — text and checklists only.
- AI Assist is explanatory/coaching only, never a scorer, across both written-exam and SSB contexts.
- Eligibility rules (age/education/marital/stream/NCC per scheme) must be admin-configurable data, not hardcoded, since official notifications change yearly — model them as a lookup table.
- All abbreviations shown to end users should expand to full form on first use or via the Glossary.

## Tech expectations
- Mobile-first, responsive up to desktop.
- Componentize: EligibilityForm, SchemeCard, ExamHub, ModuleCard, PricingCard, ExpertCard, FAQSearch.
- Use real client-side state (React state/context or equivalent) for the multi-step flows — don't hardcode a single path.
- Persist onboarding answers and eligibility results locally (localStorage or equivalent) so returning users skip re-onboarding.
